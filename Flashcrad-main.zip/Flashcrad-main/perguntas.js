criaCartao(
    'Basquete',
    'Quais são as posições dos jogadores?',
    'São cinco sendo elas: armador, ala- armardor,ala, pivo e ala- pivo.'
)

criaCartao(
    'Geografia',
    'Qual a capital da França?',
    'A capital da França é Paris'
)

criaCartao(
    'Programação',
    'O que é uma função?',
    'Uma função é um bloco de código que executa alguma tarefa'
)